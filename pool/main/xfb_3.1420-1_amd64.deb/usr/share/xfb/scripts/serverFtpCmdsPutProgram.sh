#!/bin/bash 
cd ../ftp/ 
ftp -v [IP] [PORT] << EOT 
prompt 
passive
prompt 
binary 
prompt 
cd Programs 
prompt 
mput *.ogg 
prompt 
bye 
EOT
